import 'package:flutter/material.dart';
import 'home_screen.dart';

void main() {
  runApp(MaterialApp(
      title: "Memory Card Game",
      debugShowCheckedModeBanner: false,
      home: HomeScreen()));
}
