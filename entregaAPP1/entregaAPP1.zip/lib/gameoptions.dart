class GameOptions {
  final String playerName;
  final bool imagesSelected;
  final bool numbersSelected;

  GameOptions(this.playerName, this.imagesSelected, this.numbersSelected);
}
